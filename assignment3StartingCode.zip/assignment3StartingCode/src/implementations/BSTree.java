package implementations;

public class BSTree<E extends Comparable<? super E>>
{

}
