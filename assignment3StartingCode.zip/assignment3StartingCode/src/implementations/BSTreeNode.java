package implementations;

public class BSTreeNode<E>
{

}
